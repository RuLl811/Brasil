"""
ESTRATEGIA FINAL — Momentum compuesto long-only con filtro de mercado bajista (universo B3 del listado)

Reglas (evaluadas al cierre de cada mes t, cartera mantenida durante t+1):
  1. Universo elegible: acciones del listado con market cap, sin precio congelado (<=25% de semanas sin cambio
     en 52 semanas) y monto negociado semanal mediano >= BRL 1 MM (13 semanas). Una sola clase por compañía.
  2. Señal: promedio de rankings cross-section de momentum 12-1, 9-1 y 6-1  [P(t-1)/P(t-L) - 1].
  3. Cartera: tercil superior de la señal, equal-weight (~20 nombres).
  4. Filtro de régimen (Daniel & Moskowitz 2016): si el IBOV acumula retorno negativo en los últimos 24 meses,
     se mantiene el universo elegible equal-weight en lugar del tercil ganador (el momentum sufre en rebotes
     desde mercados bajistas).
  5. Rebalanceo mensual.

Selección: elegida SOLO con 2006-2015 entre 192 variantes de la literatura; 2016-2026 es fuera de muestra.

Uso:
    python estrategia_momentum.py --prices "datos_b3 1.xlsx" --factors "factor_bra.xlsm" --cost-bps 30
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

import momentum_brasil as mb
import momentum_long_only as lo
import momentum_research as mr

PARAMS = dict(signal="combo", n_groups=3, weighting="ew", K=1, bear_months=24)


def regime(D, months=24) -> pd.Series:
    past = D["ib_brl"] / D["ib_brl"].shift(months) - 1
    return (past >= 0).astype(float).where(past.notna(), 1.0)


def build(D, S, p=PARAMS):
    w_mom = mr.overlap(mr.top_weights(S[p["signal"]], D, p["n_groups"], p["weighting"]), p["K"])
    w_univ = mr.universe_weights(D, p["weighting"])
    reg = regime(D, p["bear_months"])
    w = mr.blend(w_mom, w_univ, reg)
    return w, w_mom, w_univ, reg


def abs_stats(r: pd.Series) -> dict:
    r = r.dropna(); w = (1 + r).cumprod()
    return {"Ret. anualizado": w.iloc[-1] ** (12 / len(r)) - 1, "Vol. anualizada": r.std() * np.sqrt(12),
            "Ret/Vol": (w.iloc[-1] ** (12 / len(r)) - 1) / (r.std() * np.sqrt(12)),
            "Max Drawdown": (w / w.cummax() - 1).min(), "Peor mes": r.min(), "N meses": len(r)}


def rel_stats(r, b, to, cost_bps) -> dict:
    d = pd.concat([r, b, to], axis=1, keys=["r", "b", "to"]).dropna(subset=["r", "b"])
    ex = d.r - d.b; exn = ex - d.to.fillna(0) * 2 * cost_bps / 1e4
    te = ex.std() * np.sqrt(12); rel = (1 + d.r - d.to.fillna(0) * 2 * cost_bps / 1e4).cumprod() / (1 + d.b).cumprod()
    yearly = exn.groupby(exn.index.year).sum()
    return {"Exceso bruto anual": ex.mean() * 12, "Exceso neto anual": exn.mean() * 12, "Tracking error": te,
            "IR neto": exn.mean() * 12 / te, "t neto (NW)": lo.nw_tstat(exn), "Hit ratio mensual": (exn > 0).mean(),
            "% años con exceso > 0": (yearly > 0).mean(), "Max DD relativo (neto)": (rel / rel.cummax() - 1).min(),
            "Turnover one-way mensual": d.to.mean()}


def report(prices_path, factors_path, cost_bps=30.0, out_dir="resultados_estrategia"):
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    D = mr.load_all(prices_path, factors_path)
    S = mr.build_signals(D)
    mret = D["mret"]
    w, w_mom, w_univ, reg = build(D, S)
    first = S["mom12_1"].dropna(how="all").index.min() + 1
    r = lo.port_return(w, mret).loc[first:].rename("ESTRATEGIA")
    to = mb.turnover(w, mret).loc[first:].rename("turnover")
    r_net = (r - to * 2 * cost_bps / 1e4).rename("ESTRATEGIA_neto")
    u = lo.port_return(w_univ, mret).loc[first:].rename("UNIVERSO_EW")
    ib = D["ibov_ret"].loc[first:].rename("IBOV")
    r_mom = lo.port_return(w_mom, mret).loc[first:].rename("MOM_sin_filtro")
    R = pd.concat([r, r_net, r_mom, u, ib, to, reg.shift(1).reindex(r.index).rename("regimen_normal")], axis=1).dropna(subset=["ESTRATEGIA", "IBOV"])

    periods = {"Completo": (None, None), "In-sample 2006-2015": (None, mr.IS_END), "Fuera de muestra 2016-2026": (mr.IS_END + 1, None)}
    rel_u, rel_i, absd = {}, {}, {}
    for name, (a, z) in periods.items():
        Rp = R.loc[a:z]
        rel_u[name] = rel_stats(Rp.ESTRATEGIA, Rp.UNIVERSO_EW, Rp.turnover, cost_bps)
        rel_i[name] = rel_stats(Rp.ESTRATEGIA, Rp.IBOV, Rp.turnover, cost_bps)
        absd[(name, "Estrategia neta")] = abs_stats(Rp.ESTRATEGIA_neto)
        absd[(name, "Universo EW")] = abs_stats(Rp.UNIVERSO_EW)
        absd[(name, "IBOV")] = abs_stats(Rp.IBOV)
    rel_u, rel_i, absd = pd.DataFrame(rel_u), pd.DataFrame(rel_i), pd.DataFrame(absd)

    # Versión en BRL (control de moneda)
    fxm = mb.load_fx(factors_path).reindex(D["idx"])
    brl = lambda x: ((1 + x) * (fxm / fxm.shift(1)).reindex(x.index) - 1)
    rel_brl = pd.Series(rel_stats(brl(R.ESTRATEGIA), brl(R.UNIVERSO_EW), R.turnover, cost_bps))
    abs_brl = pd.DataFrame({"Estrategia neta (BRL)": abs_stats(brl(R.ESTRATEGIA_neto)), "IBOV (BRL)": abs_stats(brl(R.IBOV))})

    # Contribución del filtro
    st = R.regimen_normal.astype(bool)
    filt = pd.DataFrame({"meses": [st.sum(), (~st).sum()],
                         "exceso MOM sin filtro vs universo (anual)": [(R.MOM_sin_filtro - R.UNIVERSO_EW)[st].mean() * 12,
                                                                       (R.MOM_sin_filtro - R.UNIVERSO_EW)[~st].mean() * 12]},
                        index=["régimen normal", "régimen bajista"])

    # Cartera vigente: formada al último cierre mensual disponible -> se mantiene el mes siguiente
    last = w.dropna(how="all").index.max()
    cur = pd.DataFrame({"peso": w.loc[last], "score_combo": S["combo"].loc[last], "mom12_1": S["mom12_1"].loc[last],
                        "mom9_1": S["mom9_1"].loc[last], "mom6_1": S["mom6_1"].loc[last],
                        "elegible": D["eligible"].loc[last]})
    cur = cur[cur.peso.notna()].sort_values("score_combo", ascending=False)
    ib_24 = D["ib_brl"].loc[last] / D["ib_brl"].shift(24).loc[last] - 1

    # Control de producción: la cartera tiene que corresponder al último mes cerrado de los precios.
    last_closed = D["idx"].max()
    px_last = D["px_w"].index.max()
    if last != last_closed:
        n_el = int(D["eligible"].loc[last_closed].sum())
        raise RuntimeError(
            f"La última cartera formada es {last}, pero el último mes cerrado en los precios es {last_closed} "
            f"(datos hasta {px_last.date()}). Elegibles en {last_closed}: {n_el}. Revisá que las hojas close, "
            f"mkt_cap y volume estén actualizadas a la misma fecha. No se generó el Excel.")
    if D.get("fx_missing") and str(last_closed) in D["fx_missing"]:
        print(f"AVISO: falta USDBRL de {last_closed}. La cartera es válida (se forma en BRL), pero el backtest en USD "
              f"llega hasta {last_closed - 1}.")
    exec_from = (last.to_timestamp(how="end").normalize() + pd.offsets.BDay(1)).date()   # 1er día hábil (sin feriados B3)

    # Órdenes: cartera anterior (derivada por los retornos del mes, en BRL) vs cartera nueva
    prev = w.loc[last - 1].fillna(0) if (last - 1) in w.index else pd.Series(0.0, index=w.columns)
    r_brl = D["mpx"].pct_change(fill_method=None).loc[last].reindex(prev.index).fillna(0)
    drift = prev * (1 + r_brl)
    drift = drift / drift.sum() if drift.sum() > 0 else drift
    new = w.loc[last].fillna(0)
    orders = pd.DataFrame({"peso_actual_derivado": drift, "peso_objetivo": new})
    orders = orders[(orders.abs().sum(axis=1)) > 0]
    orders["operar"] = orders.peso_objetivo - orders.peso_actual_derivado
    orders["accion"] = np.select(
        [(orders.peso_actual_derivado == 0) & (orders.peso_objetivo > 0),
         (orders.peso_actual_derivado > 0) & (orders.peso_objetivo == 0)],
        ["COMPRAR (entra)", "VENDER (sale)"], default="AJUSTAR")
    orders.loc[(orders.accion == "AJUSTAR") & (orders.operar.abs() < 0.0025), "accion"] = "MANTENER"
    orders = orders.sort_values(["accion", "operar"], ascending=[True, False])

    with pd.ExcelWriter(out / "estrategia_momentum.xlsx") as xw:
        pd.Series({**PARAMS, "costos_bps_por_lado": cost_bps, "precios_hasta": str(px_last.date()),
                   "cartera_formada_al": str(last), "ejecutar_desde": str(exec_from),
                   "se_mantiene_durante": str(last + 1), "IBOV 24m (BRL) al cierre": ib_24,
                   "régimen": "normal (tercil ganador)" if not ib_24 < 0 else "bajista (universo EW)",
                   "nombres en cartera": len(cur), "turnover de este rebalanceo (one-way)": orders.operar.clip(lower=0).sum()}
                  ).to_frame("valor").to_excel(xw, sheet_name="parametros")
        cur.to_excel(xw, sheet_name="cartera_vigente")
        orders.to_excel(xw, sheet_name="ordenes")
        rel_u.to_excel(xw, sheet_name="vs_universo_EW")
        rel_i.to_excel(xw, sheet_name="vs_IBOV")
        absd.to_excel(xw, sheet_name="absoluto_USD")
        rel_brl.to_frame("vs universo EW (BRL)").to_excel(xw, sheet_name="control_BRL")
        abs_brl.to_excel(xw, sheet_name="control_BRL", startcol=4)
        filt.to_excel(xw, sheet_name="aporte_filtro")
        R.to_excel(xw, sheet_name="retornos_mensuales")
        (R.ESTRATEGIA_neto - R.UNIVERSO_EW).groupby(R.index.year).sum().to_frame("exceso neto vs universo").join(
            (R.ESTRATEGIA_neto - R.IBOV).groupby(R.index.year).sum().rename("exceso neto vs IBOV")).to_excel(xw, sheet_name="exceso_por_año")
        w.dropna(how="all", axis=1).loc[first - 1:].to_excel(xw, sheet_name="pesos_historicos")

    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
        fig, ax = plt.subplots(2, 1, figsize=(11, 8), sharex=True, gridspec_kw={"height_ratios": [2, 1]})
        x = R.index.to_timestamp()
        for c, lab in [("ESTRATEGIA_neto", "Estrategia (neta)"), ("MOM_sin_filtro", "Momentum sin filtro"),
                       ("UNIVERSO_EW", "Universo EW"), ("IBOV", "IBOV")]:
            ax[0].plot(x, (1 + R[c]).cumprod().values, label=lab)
        ax[0].set_yscale("log"); ax[0].legend(); ax[0].set_title("Riqueza acumulada (USD)")
        ax[0].axvline(pd.Timestamp("2016-01-01"), color="grey", ls="--", lw=.8)
        ax[0].text(pd.Timestamp("2016-03-01"), ax[0].get_ylim()[0] * 1.1, "fuera de muestra →", color="grey")
        rel = (1 + R.ESTRATEGIA_neto).cumprod() / (1 + R.UNIVERSO_EW).cumprod()
        ax[1].plot(x, rel.values, color="C0"); ax[1].axhline(1, color="grey", lw=.8)
        bear = ~R.regimen_normal.astype(bool)
        ax[1].fill_between(x, rel.min(), rel.max(), where=bear.values, color="C3", alpha=.12, label="régimen bajista")
        ax[1].set_title("Riqueza relativa neta vs universo EW"); ax[1].legend(loc="upper left")
        ax[1].axvline(pd.Timestamp("2016-01-01"), color="grey", ls="--", lw=.8)
        plt.tight_layout(); plt.savefig(out / "estrategia_momentum.png", dpi=130); plt.close()
    except Exception as e:
        print("Gráfico omitido:", e)

    pd.set_option("display.width", 200); pd.options.display.float_format = "{:,.3f}".format
    print(f"Estrategia: {PARAMS} | costos {cost_bps:.0f} bps/lado | {R.index.min()} a {R.index.max()}")
    print("\n=== vs universo EW (aporte de la estrategia) ===\n", rel_u)
    print("\n=== vs IBOV ===\n", rel_i)
    print("\n=== Absoluto (USD) ===\n", absd.T)
    print("\n=== Control BRL (vs universo EW) ===\n", rel_brl, "\n", abs_brl.T)
    print("\n=== Aporte del filtro de régimen ===\n", filt)
    print(f"\nCartera formada al {last} (para {last + 1}) | IBOV 24m BRL: {ib_24:.1%} -> "
          f"{'normal' if ib_24 >= 0 else 'bajista'} | {len(cur)} nombres\n", cur.round(3))
    return dict(R=R, rel_u=rel_u, rel_i=rel_i, absd=absd, cur=cur, w=w)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--prices", required=True)
    ap.add_argument("--factors", required=True)
    ap.add_argument("--cost-bps", type=float, default=30.0)
    ap.add_argument("--out", default="resultados_estrategia")
    a = ap.parse_args()
    report(a.prices, a.factors, a.cost_bps, a.out)
