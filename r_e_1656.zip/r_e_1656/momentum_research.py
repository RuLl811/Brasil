"""
Investigación de variantes de momentum long-only sobre el universo B3 del listado.

Disciplina anti-overfitting:
  * Todas las variantes provienen de la literatura (no se inventan reglas ad hoc).
  * Diseño/selección SOLO con la muestra in-sample (IS: 2006-01 a 2015-12).
  * La muestra 2016-01 a 2026-08 queda como validación fuera de muestra (OOS) y no se usa para elegir.
  * Métrica de selección: IR neto de costos vs el universo elegible con la MISMA ponderación.

Señales (fecha de formación t = fin de mes; todas usan sólo información <= t):
  mom12_1   : P(t-1)/P(t-12)-1                           Jegadeesh & Titman (1993)
  mom9_1    : P(t-1)/P(t-9)-1
  mom6_1    : P(t-1)/P(t-6)-1
  combo     : promedio de rankings de 12-1, 9-1 y 6-1
  sharpe    : retorno 12-1 / volatilidad semanal en la misma ventana (momentum ajustado por riesgo)
  resid     : momentum de retornos residuales al IBOV (beta 104 semanas), escalado por su desvío
              Blitz, Huij & Martens (2011) - versión 1 factor (mercado)
  high52    : P(t) / máximo de 52 semanas                    George & Hwang (2004)
  fip       : momentum 12-1 "continuo": ranking 12-1 + ranking de -ID (information discreteness,
              ID = signo(ret) * (%semanas negativas - %semanas positivas))   Da, Gurun & Warachka (2014)
Construcción:
  top tercil / top quintil, capped value-weight (JKP) o equal-weight;
  tenencia 1 mes o carteras superpuestas K=3 (Jegadeesh-Titman) para bajar rotación.
Overlays:
  bear      : si el IBOV acumula retorno negativo en 24 meses, se mantiene el universo (Daniel & Moskowitz 2016)
  volscale  : exposición activa = min(1, sigma_objetivo / sigma_6m del activo), sigma_objetivo = mediana expansiva
              (Barroso & Santa-Clara 2015)
"""
from __future__ import annotations

import itertools
from pathlib import Path

import numpy as np
import pandas as pd

import momentum_brasil as mb
import momentum_long_only as lo

IS_END = pd.Period("2015-12", "M")


# ----------------------------------------------------------------------------
# DATOS
# ----------------------------------------------------------------------------

def load_all(prices_path, factors_path, max_stale=0.25, min_tv_brl=1e6):
    px_w = mb.load_panel(prices_path, "close")
    cap_w = mb.load_panel(prices_path, "mkt_cap").drop(columns=["IBOV"], errors="ignore")
    vol_w = mb.load_panel(prices_path, "volume")
    ibov_w = px_w.pop("IBOV")
    drop, _ = mb.dedupe_share_classes(cap_w, px_w, vol_w)
    px_w = px_w.drop(columns=drop)
    tick = px_w.columns
    elig = mb.eligibility(px_w, vol_w, max_stale, min_tv_brl)
    fx = mb.load_fx(factors_path)

    mpx_brl = mb.to_monthly(px_w)
    idx = mpx_brl.index
    fxm = fx.reindex(idx)
    mpx_usd = mpx_brl.div(fxm, axis=0)
    mret = mpx_usd.pct_change(fill_method=None)                      # retornos de tenencia en USD
    mcap_brl = mb.to_monthly(cap_w).reindex(index=idx, columns=tick)
    mcap = mcap_brl.div(fxm, axis=0)
    # La elegibilidad se define en BRL: la cartera no puede depender de que el tipo de cambio esté cargado
    # (corrección 2026-09: sin USDBRL del último mes, el mes quedaba sin elegibles y se entregaba la cartera anterior).
    eligible = (mcap_brl.notna() & elig.reindex(index=idx, columns=tick).fillna(False).astype(bool))
    ib_brl = mb.to_monthly(ibov_w).reindex(idx)
    ibov_ret = (ib_brl / fxm).pct_change(fill_method=None)
    # Los pesos por capitalización son relativos (invariantes a la moneda): se usa el cap en BRL para no depender del FX.
    return dict(px_w=px_w, ibov_w=ibov_w, mpx=mpx_brl, mret=mret, mcap=mcap_brl, mcap_usd=mcap, eligible=eligible,
                ibov_ret=ibov_ret, ib_brl=ib_brl, idx=idx, fx_missing=[str(p) for p in idx[fxm.isna()]])


# ----------------------------------------------------------------------------
# SEÑALES (en moneda local; el ranking de retornos simples no depende de la moneda)
# ----------------------------------------------------------------------------

def xrank(df):
    return df.rank(axis=1, pct=True)


def at_month_end(weekly: pd.DataFrame, idx) -> pd.DataFrame:
    return mb.to_monthly(weekly).reindex(idx)


def build_signals(D):
    """Señales al cierre de t. Los rankings de las señales compuestas se calculan SOLO dentro del universo
    operable en t (elegible y con 12 meses de historia), para que los percentiles no dependan de acciones
    que no se pueden comprar (corrección de auditoría 2026-09)."""
    mpx, px_w, idx = D["mpx"], D["px_w"], D["idx"]
    sig = {}
    sig["mom12_1"] = mb.momentum_signal(mpx, 12, 1)
    sig["mom9_1"] = mb.momentum_signal(mpx, 9, 1)
    sig["mom6_1"] = mb.momentum_signal(mpx, 6, 1)
    univ = D["eligible"] & sig["mom12_1"].notna()
    xr = lambda df: xrank(df.where(univ))
    sig["combo"] = (xr(sig["mom12_1"]) + xr(sig["mom9_1"]) + xr(sig["mom6_1"])) / 3

    # semanales: ventana 12-1 ~ semanas [t-52, t-5] -> 48 semanas, desplazadas 4
    lr = np.log(px_w).diff()
    lm = np.log(D["ibov_w"]).diff()
    win, sk = 48, 4
    vol = lr.shift(sk).rolling(win, min_periods=36).std()
    sig["sharpe"] = sig["mom12_1"] / at_month_end(vol, idx)

    beta = lr.rolling(104, min_periods=78).cov(lm).div(lm.rolling(104, min_periods=78).var(), axis=0)
    b = beta.shift(sk)                                                 # beta conocida al inicio de la ventana de skip
    res = lr - b.mul(lm, axis=0)
    r_sum = res.shift(sk).rolling(win, min_periods=36).sum()
    r_sd = res.shift(sk).rolling(win, min_periods=36).std()
    sig["resid"] = at_month_end(r_sum / r_sd, idx)

    hi = px_w.rolling(52, min_periods=40).max()
    sig["high52"] = at_month_end(px_w / hi, idx)

    pos = (lr.shift(sk) > 0).astype(float).where(lr.notna()).rolling(win, min_periods=36).mean()
    neg = (lr.shift(sk) < 0).astype(float).where(lr.notna()).rolling(win, min_periods=36).mean()
    ID = np.sign(sig["mom12_1"]) * (at_month_end(neg, idx) - at_month_end(pos, idx))
    sig["fip"] = (xr(sig["mom12_1"]) + xr(-ID)) / 2
    # alinear disponibilidad: todas las señales exigen la historia de 12-1
    base_ok = sig["mom12_1"].notna()
    return {k: v.where(base_ok) for k, v in sig.items()}


# ----------------------------------------------------------------------------
# CARTERAS
# ----------------------------------------------------------------------------

def top_weights(score, D, n_groups=3, weighting="vw_cap"):
    return lo.top_group_weights(score, D["mcap"], D["eligible"], n_groups, weighting)


def universe_weights(D, weighting):
    if weighting == "ew":
        return lo.normalize(D["eligible"].astype(float).where(D["eligible"]))
    return lo.normalize(mb.formation_weights(D["mcap"].where(D["eligible"]), weighting))


def overlap(w: pd.DataFrame, K: int = 3) -> pd.DataFrame:
    """Carteras superpuestas: promedio de las K carteras formadas en t, t-1, ..., t-K+1."""
    if K == 1:
        return w
    acc = sum(w.shift(k).fillna(0) for k in range(K)) / K
    return lo.normalize(acc.where(acc > 0))


def blend(w_active, w_univ, expo: pd.Series):
    """Exposición e en la cartera momentum y (1-e) en el universo (misma ponderación)."""
    e = expo.reindex(w_active.index).fillna(1.0).clip(0, 1)
    out = w_active.fillna(0).mul(e, axis=0) + w_univ.fillna(0).mul(1 - e, axis=0)
    return out.where(out > 0)


def bear_state(D, months=24) -> pd.Series:
    """1 = mercado normal; 0 = IBOV (BRL) con retorno acumulado negativo en `months` meses (conocido en t)."""
    past = D["ib_brl"] / D["ib_brl"].shift(months) - 1
    return (past >= 0).astype(float).where(past.notna(), 1.0)


def volscale_expo(active_ret: pd.Series, window=6) -> pd.Series:
    """Barroso & Santa-Clara: exposición en t+1 = min(1, mediana expansiva de sigma / sigma_6m), con datos <= t."""
    sig = active_ret.rolling(window, min_periods=window).std()
    target = sig.expanding(min_periods=24).median()
    return (target / sig).clip(upper=1.0).fillna(1.0)


# ----------------------------------------------------------------------------
# EVALUACIÓN
# ----------------------------------------------------------------------------

def evaluate(r, b, to, cost_bps=30, start=None, end=None):
    d = pd.concat([r.rename("r"), b.rename("b"), to.rename("to")], axis=1).dropna(subset=["r", "b"])
    if start is not None:
        d = d.loc[start:]
    if end is not None:
        d = d.loc[:end]
    ex = d.r - d.b
    exn = ex - d.to.fillna(0) * 2 * cost_bps / 1e4
    te = ex.std() * np.sqrt(12)
    return {"exc": ex.mean() * 12, "exc_net": exn.mean() * 12, "te": te,
            "ir_net": exn.mean() * 12 / te if te > 0 else np.nan,
            "t_net": lo.nw_tstat(exn) if len(exn) > 24 else np.nan,
            "to": d.to.mean(), "n": len(d),
            "mdd_rel": ((1 + d.r).cumprod() / (1 + d.b).cumprod()).pipe(lambda x: (x / x.cummax() - 1).min())}


def run_grid(D, S, cost_bps=30):
    mret, ibov = D["mret"], D["ibov_ret"]
    univ = {w: universe_weights(D, w) for w in ["vw_cap", "ew"]}
    univ_ret = {w: lo.port_return(univ[w], mret) for w in univ}
    bear = bear_state(D)
    rows, store = [], {}
    first = S["mom12_1"].dropna(how="all").index.min() + 1
    for sname, ng, wt, K in itertools.product(S.keys(), [3, 5], ["vw_cap", "ew"], [1, 3]):
        w = overlap(top_weights(S[sname], D, ng, wt), K)
        for ov in ["none", "bear", "volscale"]:
            if ov == "bear":
                wf = blend(w, univ[wt], bear)
            elif ov == "volscale":
                act = lo.port_return(w, mret) - univ_ret[wt]
                wf = blend(w, univ[wt], volscale_expo(act))
            else:
                wf = w
            r = lo.port_return(wf, mret).loc[first:]
            to = mb.turnover(wf, mret).loc[first:]
            key = (sname, ng, wt, K, ov)
            store[key] = (wf, r, to)
            row = dict(zip(["signal", "n_groups", "weighting", "K", "overlay"], key))
            for per, (a, z) in {"IS": (None, IS_END), "OOS": (IS_END + 1, None), "FULL": (None, None)}.items():
                ev_u = evaluate(r, univ_ret[wt], to, cost_bps, a, z)
                ev_i = evaluate(r, ibov, to, cost_bps, a, z)
                row.update({f"{per}_{k}_univ": v for k, v in ev_u.items() if k in ("exc", "exc_net", "ir_net", "t_net", "te", "mdd_rel")})
                row.update({f"{per}_{k}_ibov": v for k, v in ev_i.items() if k in ("exc_net", "ir_net", "t_net")})
                row[f"{per}_to"] = ev_u["to"]
            rows.append(row)
    return pd.DataFrame(rows), store, univ, univ_ret
