"""
Momentum 12-1 en acciones brasileñas (B3), en USD y ponderado por capitalización con tope (vw_cap),
replicando la construcción de Jensen, Kelly & Pedersen (2023, "Is There a Replication Crisis in Finance?"),
y comparado contra la base de factores JKP de Brasil.

Uso:
    python momentum_brasil.py --prices "datos_b3 1.xlsx" --factors "factor_bra.xlsm"
    # opciones: --weighting {vw_cap,vw,ew} --n-groups 3 --cap-pct 0.8 --currency {usd,brl} --out resultados_mom

Construcción (defaults = JKP):
    * Señal  : ret_12_1 = P(t-1)/P(t-12) - 1 en cada fin de mes t.
               (El ranking es idéntico en BRL o USD: el factor cambiario es común a todas las acciones.)
    * Sorting: terciles cross-section; long tercil superior, short tercil inferior.
    * Pesos  : market cap en t, winsorizada en el percentil 80 del corte transversal (vw_cap).
    * Tenencia: portfolios formados en t se mantienen el mes t+1 (sin look-ahead).
    * Filtro : excluye en t acciones con precio congelado (>25% de semanas sin cambio en la ventana
               de la señal) o monto negociado semanal < BRL 1 MM (clases sin negociación real).
    * Moneda : retornos en USD (P_usd = P_brl / USDBRL de fin de mes), como los factores JKP.

Dependencias: pandas, numpy, statsmodels, openpyxl (matplotlib opcional).
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

NA = ["#N/A N/A", "#N/A", "#N/A Invalid Security", ""]


# ----------------------------------------------------------------------------
# 1. CARGA Y LIMPIEZA
# ----------------------------------------------------------------------------

def clean_ticker(col: str) -> str:
    """'BBAS3 BS EQUITY' / ' ABEV3 BS Equity ' -> 'BBAS3'; 'IBOV Index' -> 'IBOV'."""
    return re.sub(r"\s+(BS\s+Equity|Index)$", "", str(col).strip(), flags=re.I).upper()


def load_panel(path: str, sheet: str) -> pd.DataFrame:
    """Hoja ancha Bloomberg (col A = fechas, resto = tickers) -> DataFrame numérico fechas x tickers."""
    df = pd.read_excel(path, sheet_name=sheet, index_col=0, na_values=NA)
    df.index = pd.to_datetime(df.index, errors="coerce")
    df = df[df.index.notna()].sort_index()
    df = df[~df.index.duplicated(keep="last")]
    df.columns = [clean_ticker(c) for c in df.columns]
    df = df.apply(pd.to_numeric, errors="coerce")
    return df.where(df > 0)


def load_fx(path: str, sheet: str = "USDBRL") -> pd.Series:
    """USDBRL (BRL por 1 USD). Col A = fecha, col B = valor. Indexado por mes (Period)."""
    fx = pd.read_excel(path, sheet_name=sheet, index_col=0, na_values=NA).iloc[:, 0]
    fx.index = pd.to_datetime(fx.index, errors="coerce")
    fx = pd.to_numeric(fx, errors="coerce").dropna()
    fx = fx[fx.index.notna()].sort_index()
    fx.index = fx.index.to_period("M")
    return fx[~fx.index.duplicated(keep="last")].rename("USDBRL")


def load_factors(path: str, sheet: str = "All_factors") -> pd.DataFrame:
    """Factores JKP (cluster) en formato largo (name, date, ret) -> ancho mes x factor. USD, decimales."""
    f = pd.read_excel(path, sheet_name=sheet, usecols="A:G").dropna(subset=["name", "date", "ret"])
    f["date"] = pd.to_datetime(f["date"]).dt.to_period("M")
    return f.pivot_table(index="date", columns="name", values="ret", aggfunc="mean").sort_index()


def load_jkp_momentum(path: str, sheet: str = "Momo", col: str = "ret_12_1") -> pd.Series | None:
    """Factor JKP individual ret_12_1 (benchmark exacto de la señal que construimos)."""
    try:
        m = pd.read_excel(path, sheet_name=sheet, usecols="A:F", index_col=0)
    except Exception:
        return None
    m = m[m.index.notna()]
    m.index = pd.to_datetime(m.index).to_period("M")
    return m[col].rename(f"JKP_{col}") if col in m.columns else None


def to_monthly(df: pd.DataFrame | pd.Series, drop_incomplete: bool = True):
    """Semanal -> mensual (último dato del mes). Descarta el último mes sólo si todavía puede llegar otra
    observación dentro de él: último dato + paso típico de la serie <= fin de mes calendario.
    (Corrección de auditoría 2026-09: antes se exigía que el último dato cayera el último día calendario,
    lo que descartaba meses cerrados cuyo último viernes no coincide con el fin de mes.)"""
    m = df.resample("ME").last()
    m.index = m.index.to_period("M")
    idx = df.index
    last = idx.max()
    step = pd.Series(idx).diff().median() if len(idx) > 2 else pd.Timedelta(days=7)
    if drop_incomplete and last + step <= last + pd.offsets.MonthEnd(0):
        m = m.iloc[:-1]
    return m


def dedupe_share_classes(cap: pd.DataFrame, px: pd.DataFrame, vol: pd.DataFrame | None, tol: float = 1e-3):
    """Bloomberg reporta el market cap de la COMPAÑÍA en cada clase (PETR3 = PETR4). Se agrupan tickers cuyo
    cap coincide (mediana de |ratio - 1| < tol en las últimas 26 observaciones comunes) y se conserva la
    clase más líquida (mayor monto negociado medio en BRL). Devuelve (tickers a descartar, tabla de grupos)."""
    c = cap.dropna(how="all")
    cols = [t for t in c.columns if c[t].notna().sum() >= 5]
    parent = {t: t for t in cols}
    def find(t):
        while parent[t] != t:
            t = parent[t]
        return t
    for i, a in enumerate(cols):
        for b_ in cols[i + 1:]:
            both = c[[a, b_]].dropna().iloc[-26:]
            if len(both) >= 5 and (both[a] / both[b_] - 1).abs().median() < tol:
                parent[find(b_)] = find(a)
    groups = {}
    for t in cols:
        groups.setdefault(find(t), []).append(t)
    drop, rows = [], []
    for members in groups.values():
        if len(members) < 2:
            continue
        if vol is not None:
            liq = {t: (px[t] * vol.get(t, np.nan)).mean() for t in members}
        else:
            liq = {t: px[t].notna().sum() for t in members}
        keep = max(liq, key=lambda k: np.nan_to_num(liq[k]))
        drop += [t for t in members if t != keep]
        rows.append({"conserva": keep, "descarta": ", ".join(t for t in members if t != keep)})
    return drop, pd.DataFrame(rows)


def eligibility(px_w: pd.DataFrame, vol_w: pd.DataFrame | None, max_stale: float = 0.25,
                min_tv_brl: float = 1e6, stale_window: int = 52, tv_window: int = 13) -> pd.DataFrame:
    """Filtro de elegibilidad (booleano mes x ticker) evaluado en la fecha de formación t, con datos semanales.
    (i) Precio congelado: fracción de semanas sin cambio de precio en las últimas `stale_window` semanas
        (= la ventana de la señal 12-1) <= max_stale. Evita señales ficticias de clases sin negociación
        (p.ej. PCAR3 2006-2019, CPLE3/VIVT3/AURE3 antes de migrar de clase, LREN3/RADL3 pre-liquidez).
    (ii) Liquidez: mediana del monto negociado semanal (precio BRL x volumen) en las últimas `tv_window`
        semanas >= min_tv_brl. Se evalúa en BRL nominales."""
    stale = ((px_w.diff() == 0) & px_w.notna()).astype(float).where(px_w.notna())
    ok = stale.rolling(stale_window, min_periods=int(stale_window * 0.8)).mean() <= max_stale
    if vol_w is not None and min_tv_brl > 0:
        tv = (px_w * vol_w.reindex_like(px_w)).rolling(tv_window, min_periods=int(tv_window * 0.6)).median()
        ok &= tv >= min_tv_brl
    return to_monthly(ok.astype(float)).fillna(0).astype(bool)


# ----------------------------------------------------------------------------
# 2. SEÑAL
# ----------------------------------------------------------------------------

def momentum_signal(mpx: pd.DataFrame, lookback: int = 12, skip: int = 1) -> pd.DataFrame:
    """Score_t = P_{t-skip} / P_{t-lookback} - 1 (rolling, por activo)."""
    return mpx.shift(skip) / mpx.shift(lookback) - 1.0


# ----------------------------------------------------------------------------
# 3. SORTING Y PORTFOLIOS
# ----------------------------------------------------------------------------

def assign_groups(score: pd.DataFrame, n_groups: int = 3, min_stocks: int = 25) -> pd.DataFrame:
    """Ranking cross-sectional: 1 = perdedores ... n_groups = ganadores. NaN si hay < min_stocks."""
    def _one(row):
        v = row.dropna()
        if len(v) < max(min_stocks, 2 * n_groups):
            return pd.Series(np.nan, index=row.index)
        return (pd.qcut(v.rank(method="first"), n_groups, labels=False) + 1).reindex(row.index)
    return score.apply(_one, axis=1)


def formation_weights(cap: pd.DataFrame, weighting: str = "vw_cap", cap_pct: float = 0.8) -> pd.DataFrame:
    """Peso base en t. vw_cap: market cap winsorizada en el percentil `cap_pct` del corte transversal."""
    if weighting == "ew":
        return cap.notna().astype(float).where(cap.notna())
    if weighting == "vw":
        return cap
    if weighting == "vw_cap":
        return cap.clip(upper=cap.quantile(cap_pct, axis=1), axis=0)
    raise ValueError(weighting)


def portfolio_returns(groups, mret, base_w, n_groups):
    """Grupos y pesos de t aplicados al retorno de t+1. Devuelve retornos por grupo, LS y pesos del LS."""
    g, w0 = groups.shift(1), base_w.shift(1).reindex_like(groups.shift(1))
    out, weights = {}, {}
    for k in range(1, n_groups + 1):
        w = w0.where((g == k) & mret.notna())
        w = w.div(w.sum(axis=1).replace(0, np.nan), axis=0)
        weights[k] = w
        out[f"Q{k}"] = (w * mret).sum(axis=1, min_count=1)
    port = pd.DataFrame(out).dropna(how="all")
    port["LS"] = port[f"Q{n_groups}"] - port["Q1"]
    return port, weights


def turnover(w: pd.DataFrame, mret: pd.DataFrame) -> pd.Series:
    """Turnover one-way mensual: 0.5 * sum|w_t - w_{t-1} drifted|."""
    w = w.fillna(0)
    drift = w.shift(1) * (1 + mret.fillna(0))
    drift = drift.div(drift.sum(axis=1).replace(0, np.nan), axis=0).fillna(0)
    return 0.5 * (w - drift).abs().sum(axis=1)


# ----------------------------------------------------------------------------
# 4. PERFORMANCE
# ----------------------------------------------------------------------------

def performance_stats(r: pd.Series, periods: int = 12) -> pd.Series:
    r = r.dropna()
    ann_vol = r.std(ddof=1) * np.sqrt(periods)
    wealth = (1 + r).cumprod()
    return pd.Series({
        "Ret. anualizado": wealth.iloc[-1] ** (periods / len(r)) - 1,
        "Media anual (aritm.)": r.mean() * periods,
        "Vol. anualizada": ann_vol,
        "Sharpe": r.mean() * periods / ann_vol if ann_vol > 0 else np.nan,
        "Max Drawdown": (wealth / wealth.cummax() - 1).min(),
        "t-stat media": r.mean() / (r.std(ddof=1) / np.sqrt(len(r))),
        "Hit ratio": (r > 0).mean(),
        "N meses": len(r)})


def stats_table(df: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame({c: performance_stats(df[c]) for c in df.columns})


# ----------------------------------------------------------------------------
# 5. REGRESIONES
# ----------------------------------------------------------------------------

def ols_alpha(y: pd.Series, X: pd.DataFrame, hac_lags: int = 6) -> pd.DataFrame:
    d = pd.concat([y.rename("y"), X], axis=1).dropna()
    res = sm.OLS(d["y"], sm.add_constant(d.drop(columns="y"))).fit(cov_type="HAC", cov_kwds={"maxlags": hac_lags})
    tab = pd.DataFrame({"coef": res.params, "t (NW)": res.tvalues, "p-value": res.pvalues})
    tab.loc["const", "alfa anual"] = res.params["const"] * 12
    tab.attrs.update(r2=res.rsquared, nobs=int(res.nobs))
    return tab


def factor_league_table(bench: pd.DataFrame) -> pd.DataFrame:
    b = bench.dropna()
    t = pd.DataFrame({"Media anual": b.mean() * 12, "Vol anual": b.std() * np.sqrt(12)})
    t["Sharpe"] = t["Media anual"] / t["Vol anual"]
    t["t-stat"] = b.mean() / (b.std() / np.sqrt(len(b)))
    t = t.sort_values("Sharpe", ascending=False)
    t.attrs["n_meses"] = len(b)
    return t


# ----------------------------------------------------------------------------
# 6. PIPELINE
# ----------------------------------------------------------------------------

def build_strategy(prices_path, factors_path, n_groups=3, lookback=12, skip=1, weighting="vw_cap",
                   cap_pct=0.8, min_stocks=25, currency="usd", verbose=True,
                   max_stale=0.25, min_tv_brl=1e6):
    """Construye la estrategia y devuelve dict con retornos, pesos y metadatos."""
    px_w = load_panel(prices_path, "close")
    cap_w = load_panel(prices_path, "mkt_cap")
    try:
        vol_w = load_panel(prices_path, "volume")
    except Exception:
        vol_w = None
    ibov_w = px_w.pop("IBOV") if "IBOV" in px_w else None
    cap_w = cap_w.drop(columns=["IBOV"], errors="ignore")         # cap total del índice, no es una acción

    drop, dup_tab = dedupe_share_classes(cap_w, px_w, vol_w)
    px_w = px_w.drop(columns=drop, errors="ignore")
    tickers = px_w.columns

    elig = eligibility(px_w, vol_w, max_stale, min_tv_brl) if max_stale < 1 or min_tv_brl > 0 else None
    mpx = to_monthly(px_w)
    mcap = to_monthly(cap_w).reindex(index=mpx.index, columns=tickers)
    fx = load_fx(factors_path)
    if currency == "usd":
        fx_m = fx.reindex(mpx.index)
        if fx_m.isna().any():
            raise ValueError(f"Faltan {fx_m.isna().sum()} meses de USDBRL: {list(fx_m[fx_m.isna()].index)}")
        mpx = mpx.div(fx_m, axis=0)
        mcap = mcap.div(fx_m, axis=0)                               # no altera pesos relativos; solo consistencia
    mret = mpx.pct_change(fill_method=None)

    score = momentum_signal(mpx, lookback, skip)
    eligible = mcap.notna()                                          # exige cap para ser elegible
    if elig is not None:
        eligible &= elig.reindex(index=mpx.index, columns=tickers).fillna(False).astype(bool)
    groups = assign_groups(score.where(eligible), n_groups, min_stocks)
    base_w = formation_weights(mcap, weighting, cap_pct)
    port, weights = portfolio_returns(groups, mret, base_w, n_groups)

    if ibov_w is not None:
        ib = to_monthly(ibov_w)
        if currency == "usd":
            ib = ib / fx.reindex(ib.index)
        port["MKT_IBOV"] = ib.pct_change(fill_method=None).reindex(port.index)

    to = pd.DataFrame({"long": turnover(weights[n_groups], mret), "short": turnover(weights[1], mret)}).reindex(port.index)
    n_names = pd.DataFrame({f"Q{k}": weights[k].notna().sum(axis=1) for k in (1, n_groups)}).reindex(port.index)
    if verbose and len(dup_tab):
        print("Clases duplicadas (mismo market cap de compañía):\n", dup_tab.to_string(index=False))
    return dict(port=port, groups=groups, weights=weights, turnover=to, n_names=n_names,
                n_universe=len(tickers), dup=dup_tab, mret=mret, eligible=eligible,
                score=score, mcap=mcap)


def run(prices_path, factors_path, n_groups=3, lookback=12, skip=1, weighting="vw_cap", cap_pct=0.8,
        min_stocks=25, currency="usd", hac_lags=6, out_dir="resultados_mom", momentum_name="momentum",
        max_stale=0.25, min_tv_brl=1e6):
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    S = build_strategy(prices_path, factors_path, n_groups, lookback, skip, weighting, cap_pct, min_stocks, currency,
                       max_stale=max_stale, min_tv_brl=min_tv_brl)
    port = S["port"]
    ls = port["LS"].rename("MOM_propio")

    fac = load_factors(factors_path)
    jkp = load_jkp_momentum(factors_path)
    perf = stats_table(port)

    # Ranking de primas en muestra común: 13 clusters JKP + ret_12_1 JKP + nuestra estrategia
    bench = fac.join(jkp) if jkp is not None else fac.copy()
    league = factor_league_table(bench.join(ls, how="inner"))

    # Regresiones
    controls = [c for c in fac.columns if c != momentum_name]
    regs = {
        "A_todos_clusters+MKT": ols_alpha(ls, fac[controls].join(port["MKT_IBOV"]), hac_lags),
        "B_size_value_quality_lowrisk+MKT": ols_alpha(
            ls, fac[[c for c in ["size", "value", "quality", "low_risk"] if c in fac]].join(port["MKT_IBOV"]), hac_lags),
        "C_vs_cluster_momentum": ols_alpha(ls, fac[[momentum_name]], hac_lags),
    }
    if jkp is not None:
        regs["D_vs_JKP_ret_12_1"] = ols_alpha(ls, jkp.to_frame(), hac_lags)
        regs["E_JKP_ret_12_1_vs_clusters+MKT"] = ols_alpha(jkp, fac[controls].join(port["MKT_IBOV"]), hac_lags)
    corr = ls.to_frame().join(fac[[momentum_name]]).join(jkp).corr().iloc[0, 1:]

    with pd.ExcelWriter(out / "resultados_momentum.xlsx") as xw:
        port.to_excel(xw, sheet_name="retornos")
        perf.to_excel(xw, sheet_name="performance")
        league.to_excel(xw, sheet_name="ranking_factores")
        for k, t in regs.items():
            t.to_excel(xw, sheet_name=("OLS_" + k)[:31])
        S["turnover"].join(S["n_names"]).to_excel(xw, sheet_name="turnover_y_n")
        S["weights"][n_groups].dropna(how="all", axis=1).to_excel(xw, sheet_name="pesos_long")
        S["weights"][1].dropna(how="all", axis=1).to_excel(xw, sheet_name="pesos_short")
        S["dup"].to_excel(xw, sheet_name="clases_duplicadas", index=False)

    pd.options.display.float_format = "{:,.4f}".format
    print(f"\nUniverso: {S['n_universe']} acciones | {currency.upper()} | {weighting} (p{int(cap_pct*100)}) | "
          f"{n_groups} grupos | {lookback}-{skip} | {port.index.min()} a {port.index.max()} ({len(port)} meses)")
    print("\n=== Performance ===\n", perf)
    print(f"\nTurnover one-way medio mensual: long {S['turnover']['long'].mean():.1%}, short {S['turnover']['short'].mean():.1%}"
          f" | nombres medios por pierna: {S['n_names'].mean().round(1).to_dict()}"
          f" | elegibles medios: {S['eligible'].sum(axis=1).loc[port.index].mean():.1f}")
    print(f"\n=== Ranking de factores (muestra común {league.attrs['n_meses']} meses) ===\n", league)
    print("\nCorrelación MOM_propio vs:", corr.round(3).to_dict())
    for k, t in regs.items():
        print(f"\n=== OLS {k} | R2={t.attrs['r2']:.3f} N={t.attrs['nobs']} (NW {hac_lags}) ===\n", t)

    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
        cum = port[["Q1", f"Q{n_groups}", "LS", "MKT_IBOV"]].join(jkp).dropna()
        (1 + cum).cumprod().plot(logy=True, figsize=(10, 5), title=f"Momentum 12-1 ({currency.upper()}, {weighting})")
        plt.tight_layout(); plt.savefig(out / "equity_curve.png", dpi=130); plt.close()
    except Exception as e:
        print("Gráfico omitido:", e)
    return dict(S=S, perf=perf, league=league, regs=regs, corr=corr)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--prices", required=True)
    ap.add_argument("--factors", required=True)
    ap.add_argument("--n-groups", type=int, default=3)
    ap.add_argument("--lookback", type=int, default=12)
    ap.add_argument("--skip", type=int, default=1)
    ap.add_argument("--weighting", default="vw_cap", choices=["vw_cap", "vw", "ew"])
    ap.add_argument("--cap-pct", type=float, default=0.8)
    ap.add_argument("--min-stocks", type=int, default=25)
    ap.add_argument("--currency", default="usd", choices=["usd", "brl"])
    ap.add_argument("--hac-lags", type=int, default=6)
    ap.add_argument("--max-stale", type=float, default=0.25, help="máx. fracción de semanas con precio sin cambio (1 = sin filtro)")
    ap.add_argument("--min-tv", type=float, default=1e6, help="monto negociado semanal mínimo en BRL (0 = sin filtro)")
    ap.add_argument("--out", default="resultados_mom")
    a = ap.parse_args()
    run(a.prices, a.factors, a.n_groups, a.lookback, a.skip, a.weighting, a.cap_pct,
        a.min_stocks, a.currency, a.hac_lags, a.out,
        max_stale=a.max_stale, min_tv_brl=a.min_tv)
